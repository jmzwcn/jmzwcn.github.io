// +build !linux,!freebsd,!windows,!solaris

package daemon

const platformSupported = false
