// +build !windows

package container

const (
	testAbsPath = "/foo"
)
