// +build !linux

package daemon

var supportsSeccomp = false
